How to play the game
    Run on main 
    There is no start screen the game just puts you right in
    There is also no restart screen so you load to reload the game after you lose (there is no winning L)
    some Basics before you start
    this is a card battler meaning that cards are your skills/attacks
    start by picking a card by clicking on it and then line should appear this line follows your mouse.
    while this line is drawn try to click on the enemy to apply this card
        there are 5 cards you can get currently
        Attack  (Red Card)-> card just causes damage to enemies
        Defense (Green Card)-> this card applies shield to you and this shield blocks some incoming damage
        Dex (Other Green Card)-> This card gives you dexerity which applies defense to you after your turn
        Strength (Blue Card) -> adds directly to the damage you do
    you also notice you have energy, the images on how much energy the cards cost is not accurate, and they probably aren't changing but
    you cast the cards until you run out of energy or decide to not cast them
    now you are done with your turn -> you click the blue button to right
    to end your turn

    Lets say you live long enough to make it to the next stage
    the stage can either be another combat stage or a potenial shop, this shop has relics and to buy the relics
    you click on them but you have to have the gold to buy them
    after buying all of these relic (which will help you later) you press end turn again
    and you are either put into another shop or upgrade stage or combat
    in an update stage aslong as you have the stat points (which you get from killing enemies) you can level up certain stats

    This is the essential gameplay loop there are other things you may want to keep an eye out for
        enemies can debuff you were they give you minus strength
        enemies show their intetion when they are about to cast it
            and up means they are buffing themselves
            a down means they are debuffing you
            a sword means that they will attack soon
            and a shield means they will defend soon.
            keep in mind that enemies have different strategies each of the 6 enemies have different ranges for when they will attack or defend
            and how much they will attack a defending for

Sources:
    All of the assets and code was written or created by me
    the gameplay is loosely based off of slay the spire the video game
    with the nunchuks, the boot, the anchor, the kunai, and the redskull being ideas from slay the spire
    https://slay-the-spire.fandom.com/wiki/Relics
    
    the modules i used only included:
        PIL, CMU Graphics, Random, OS (for PIL)
        and path lib
    all code was created by me and thought of by me the stateMachine name and idea are loosely based off project i have done before